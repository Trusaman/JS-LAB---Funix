// 5.1
//Tạo một object là 'myCountry' cho quốc gia bạn chọn, chứa các thuộc tính 'country', 'capital', 'language', 'population' and 'neighbours' (array như chúng ta đã thực hành trong bài trước).

const myCountry = {
    country: 'Finalnd',
    capital: 'Helsinki',
    languge: 'finnish',
    population: 6,
    neighbours: ['Norway', 'Sweden', 'Russia'],
    describe: function () {
        console.log(`${this.country} has ${this.population} million ${this.language}-speaking people, ${this.neighbours.length} neighbouring countries and capital called ${this.capital}.`);
    },
    checkIsland:  function () {
        this.isIsland = this.neighbours.length == 0 ? true : false
    }
}

myCountry.describe()
myCountry.checkIsland()


//Lab 5.4. Vòng lặp For (5 phút)

//Ở đất nước bạn có các cuộc bầu cử. Ở một thị trấn nhỏ, chỉ có 50 cử tri. Sử dụng vòng lặp for để mô phỏng 50 cử tri này, bằng cách in string sau ra console (cho các số từ 1 đến 50): 'Voter number 1 is currently voting'.

for (let i = 1; i <= 50; i++) {
    console.log(`Voter number ${i} is currently voting`)
}

// import { populations, percentageOfWorld1 } from "./04-lab"

let populations = [10, 80, 90, 1000]

function percentageOfWorld1(population) {
    return Math.round(population / 7900 * 100) / 100
}

let percentages2 = []

for (let i = 0; i < populations.length; i++) {
    percentages2.push(percentageOfWorld1(populations[i]))
}

let temp_percentages = [percentageOfWorld1(10), percentageOfWorld1(80), percentageOfWorld1(90), percentageOfWorld1(1000)]

function checkArray(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        if (arr1[i] !== arr2[i]) return false
    }
    return true
}

checkArray(percentages2, temp_percentages)

/*Lab 5.6. Vòng lặp ngược và Vòng lặp trong vòng lặp (15 phút)

Lưu trữ array của những array này vào biến 'listOfNeighbours' [['Canada', 'Mexico'], ['Spain'], ['Norway', 'Sweden', 'Russia']];
Hiển thị các quốc gia láng giềng vào màn hình console, không phải toàn bộ array. Ví dụ 'Neighbour: Canada' cho từng quốc gia.
Bạn sẽ cần một vòng lặp bên trong vòng lặp cho điều này. Điều này thực sự hơi phức tạp, vì vậy đừng lo lắng nếu nó quá khó đối với bạn! Bạn sẽ giải quyết được vấn đề này. 
*/

let listOfNeighbours = [['Canada', 'Mexico'], ['Spain'], ['Norway', 'Sweden', 'Russia']];

for (let i = 0; i < listOfNeighbours.length; i++) {
    for (let j = 0; j < listOfNeighbours[i].length; j++) {
        console.log(`Neighbor: ${listOfNeighbours[i][j]}`)
    }
}

/*Lab 5.7. Vòng lặp While (10 phút)

Lấy lại từ lab Lặp trong array, break và continue, nhưng lần này hãy sử dựng vòng lặp while (gọi array 'percentages3').
Bạn thích giải pháp nào hơn cho nhiệm vụ này: vòng lặp for hay vòng lặp while?
*/
let i = 0
while (i < listOfNeighbours.length) {
    let j = 0
    while (j < listOfNeighbours[i].length) {
        console.log(`Neighbor: ${listOfNeighbours[i][j]}`)
        j++
    }
    i++
}

/*Lab 5.8.1. So sánh chỉ số IBM (phần 3)

Hãy quay lại ví dụ so sánh chỉ số BMI của Mark và John! Lần này, hãy dùng object để triển khai các phép tính! Nhớ rằng: BMI = mass/[(height)^2)] = mass/(height*height) (mass tính bằng kg và height tính bằng mét)

1. Nhiệm vụ của bạn:

Với mỗi người (Mark Miller và John Smith), hãy tạo một object có các thuộc tính như full name, mass, and height 
Tạo phương thức 'calcBMI' ở mỗi object để tính BMI (phương thức như nhau ở cả hai object). Lưu giá trị BMI vào một thuộc tính và trả về từ phương thức.
In ra console người có BMI cao hơn cùng với tên đầy đủ và BMI tương ứng. Ví dụ: "John's BMI (28.3) is higher than Mark's (23.9)!"
*/

const person1 = {
    fullName: "Mark Miller",
    mass: 78,
    height: 169,
    calcBMI: function() {
        this.BMI = this.mass / (this.height ** 2)
    }
}

const person2 = {
    fullName: "John Smith",
    mass: 92,
    height: 195,
    calcBMI: function() {
        this.BMI = this.mass / (this.height ** 2)
    }
}

/*Lab 5.8.2. Cải thiện Tip calculator

Hãy cải thiện thêm tip calculator của Steven, lần này sử dụng các vòng lặp!

1. Nhiệm vụ của bạn:

Tạo array 'bills' chứa tất cả 10 giá trị hóa đơn kiểm tra.
Tạo các array rỗng cho 'tips' và 'totals'.
Sử dụng hàm 'calcTip' mà chúng ta đã viết trước đó (không cần lặp lại) để tính các giá trị tips và totals (hóa đơn + tiền boa) cho mỗi giá trị bill trong bills array. Sử dụng vòng lặp for để thực hiện 10 phép tính!.
*/

const bills = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52]

const tips = []
const totals = []

const calcTip = function(bill) {
    return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
}

for (let i = 0; i < bills.length; i++) {
    tips.push(calcTip(bills[i]))
    totals.push(bills[i] + calcTip(bills[i]))
}

