let country = "Viet Nam"
let continent = "Asia"
let population = 97340000

console.log("My country is: ", country);
console.log("The continent of My country is: ", continent);
console.log("My country's polupation is: ", population);