// Lab 13.1: Tạo Object

// 1. Nhiệm vụ của bạn

// Sử dụng một hàm tạo để triển khai 'Car'. Một chiếc ô tô có thuộc tính 'make' và 'speed'. Thuộc tính 'speed' là tốc độ hiện tại của ô tô tính bằng km/h.
// Triển khai phương thức 'accelerate' tăng tốc độ của ô tô thêm 10 km/h và in tốc độ mới ra console.
// Triển khai phương thức 'brake' giảm bớt tốc độ của ô tô 5 km/h và in tốc độ mới ra console.
// Tạo 2 object 'Car' và thử nghiệm với 'accelerate' và 'brake' nhiều lần trên mỗi object.

function Car(make, speed) {
    this.make = make;
    this.speed = speed
}

Car.prototype.accelerate = function () {
    this.speed += 10
    console.log(this.speed);
}

Car.prototype.brake = function () {
    this.speed -= 5
    console.log(this.speed);
}

const bmw = new Car("BMW", 130)
bmw.accelerate()
bmw.brake()









// Lab 13.2: Sử dụng ES6 Class

// 1. Nhiệm vụ của bạn

// Tạo lại như class Car lab 13.1, nhưng lần này sử dụng ES6 class (gọi nó là 'CarCl').
// Thêm một getter là 'speedUS', trả về tốc độ hiện tại tính bằng mile/h (bạn cần quy điểm km/h thành mile/h bằng cách chia cho 1.6).
// Thêm một setter gọi là 'speedUS' để đặt giá trị tốc độ hiện tại tính bằng mile/h. (giá trị của tham số sẽ là ở mile/h, khi lưu vào object thì bạn sẽ lưu ở đơn vị km/h bằng cách nhân với 1.6).
// Tạo một đối tượng Car mới, thử nghiệm với phương thức 'accelerate' và 'brake', với getter và setter.

class CarCI {
    constructor(make, speed) {
        this.make = make;
        this.speed = speed
    }
    accelerate() {
        this.speed += 10
        console.log(this.speed);
    }
    brake() {
        this.speed -= 5
        console.log(this.speed);
    }
    get speedUS() {
        return this.speed / 1.6
    }
    set speedUS(newSpeed) {
        this.speed = newSpeed * 1.6
    }
}

let mazda = new CarCI("Mazda", 2000)
console.log(mazda.speedUS)
mazda.speedUS = 2000


