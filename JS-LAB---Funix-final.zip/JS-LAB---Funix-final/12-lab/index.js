// Lab 12.1: Phân loại thú cưng
// Tạo hàm 'checkDogs', nhận 2 array tuổi của chó ('dogJulia' và 'dogKate') và thực hiện những điều sau:

// Julia phát hiện ra rằng chủ nhân của chú chó đầu tiên và cuối cùng thực ra nuôi mèo chứ không phải chó! Vì vậy, hãy tạo một bản sao array của Julia và xóa tuổi mèo khỏi array đã sao chép đó (không nên thay đổi các tham số hàm).
// Tạo một array với cả dữ liệu của Julia (đã sửa) và của Kate.
// Đối với mỗi chú chó còn lại, hãy in ra console đó là chú chó trưởng thành ("Dog number 1 is an adult, and is 5 years old") hay chó con ("Dog number 2 is still a puppy").
// Chạy hàm cho cả hai tập dữ liệu kiểm tra.

function checkDogs(dogJulia, dogKate) {
    dogs = [...dogJulia.slice(1, dogJulia.length - 1), ...dogKate]
    dogs.forEach((dog, idx) => {
        if (dog >= 3) {
            console.log(`Dog number ${idx+ 1} is adult, and is ${dog} years old`);
        } else {
            console.log(`Dog number ${idx + 1} is still a puppey`);
        }
    });
}

checkDogs([3, 5, 2, 12, 7], [4, 1, 15, 8, 3]) //result: [5, 2, 12, 4, 1, 15, 8, 3]

// Lab 12.2: Chuyển đổi tuổi thú cưng
// Tạo hàm 'calcAverageHumanAge', hàm này nhận array tuổi của chó ('age') và thực hiện những việc sau theo thứ tự:

// Tính tuổi của chó theo năm như tuổi người theo công thức sau: if the dog is <= 2 years old, humanAge = 2 * dogAge. If the dog is > 2 years old, humanAge = 16 + dogAge * 4.
// Loại trừ tất cả những chú chó có humanAge dưới 18 (điều này cũng giống như việc giữ những chú chó có humanAge từ 18 tuổi trở lên).
// Tính humanage trung bình của các chú chó trưởng thành (bạn nên biết từ những thử thách khác về cách tính trung bình).
// Chạy hàm cho hai tập dữ liệu kiểm tra.

function calcAverageHumanAge(dogs) {
    //Tính tuổi của chó theo năm như tuổi người theo công thức sau: if the dog is <= 2 years old, humanAge = 2 * dogAge. If the dog is > 2 years old, humanAge = 16 + dogAge * 4.
    humanDogs = dogs.map(dog => {
        if (dog <= 2) return 2 * dog
        return 16 + dog * 4
    }).filter(dog => dog > 18)
    return console.log(humanDogs.reduce((a, b) => a + b, 0) / humanDogs.length)

}

calcAverageHumanAge([5, 2, 4, 1, 15, 8, 3])
calcAverageHumanAge([16, 6, 10, 5, 6, 1, 4])