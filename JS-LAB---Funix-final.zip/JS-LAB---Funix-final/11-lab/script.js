const poll = {
    question: "What is your favourite programming language? ",
    options: ["0: JavaScript", "1: Python", "2: Rust", "3: C++"],
    numberOfVotes: new Array(4).fill(0),
    registerNewAnswer: function () {
        while (true) {
            let answer = prompt(`What is your favourite programming language?\n${this.options[0]}\n${this.options[1]}\n${this.options[2]}\n${this.options[3]}`)
            if (isNaN(answer) || !answer || answer < 0 || answer > 3) {
                alert("Not correct answer!!")
                continue
            } else {
                console.log("DONE");
                this.numberOfVotes[answer]++
                break
            }

        }
    },
    displayResults: function (params) {
        if (typeof (params) == "string") return console.log("Poll results are", params.replace(/\[/, "").replace(/\]/, ""));
        if (Array.isArray(params)) return console.log(params);
    }
}

function answerQuest() {
    poll.registerNewAnswer()
}