let country = "Viet Nam"
let continent = "Asia"
let population = 97.34

let isIsland = false
let language

// 2.1
console.log("My country is a island? ", isIsland)
console.log("Population is: ", population);
console.log("Country is: ", country);
console.log("Language is: ", language);

// Lab 2.2. Let, const và var 

language = "Vietnamese"

const pi = 3.14

pi = 10

// Lab 2.3. Các toán tử cơ bản
console.log("1 nua cuar dan so: ", population / 2);

console.log(population + 1);

console.log("the pop is:", population > 6);

console.log(population < 33);

let description = `${country} and its ${population} million people speak ${language}`

// Lab 2.4. String và Template Literal 

let description = `${country} and its ${population} million people speak ${language}`

// Lab 2.5. Đưa ra quyết định: Câu lệnh if/else

if (population > 33) {
    console.log(`${country}'s population is above average`);
} else {
    console.log(`${country}'s population is ${33 - population} million below average`);    
}

/**
 * Lab 2.6.1. So sánh chỉ số IBM (phần 1)

Mark và John đang cố so sánh chỉ số BMI (Body Mass Index) của họ, được tính bằng công thức: BMI = mass/[(height)^2)] = mass/(height*height) (mass tính bằng kg và height tính bằng mét).

1. Nhiệm vụ của bạn:

Lưu khối lượng và chiều cao của Mark và John vào các biến.
Tính chỉ số BMI của John và Mark theo công thức (bạn có thể tính cả hai).
Tạo biến Boolean 'markHigherBMI' chứa thông tin về việc liệu chỉ số BMI của Mark có cao hơn BMI của John không.

2. Dữ liệu kiểm tra:

Dữ liệu 1: Mark nặng 78 kg và cao 1.69 m. John nặng 92 kg và cao 1.95 m.
Dữ liệu 2: Mark nặng 95 kg và cao 1.88 m. John nặng 85 kg và cao 1.76 m.

**/

let mWeight = 78
let mHeight = 1.69
let markBMI = mWeight / (mHeight ** 2)

let jWeight = 92
let jHeight = 1.95
let johnBMI = jWeight / (jHeight ** 2)

let markHigherBMI = markBMI > johnBMI

// Lab 2.6.2. So sánh chỉ số IBM (phần 2)

// Sử dụng ví dụ về BMI từ Lab 2.6.1 và code bạn đã viết để cải thiện lại.

// 1. Nhiệm vụ của bạn:

// In một output tốt ra console, hiển thị ai có chỉ số BMI cao hơn. Thông báo hiển thị sẽ là "Mark's BMI is higher than John's!"  hoặc "John's BMI is higher than Mark's!".
// Sử dụng template literal bao gồm các giá trị BMI trong output. Ví dụ: "Mark's BMI (28.3) is higher than John's (23.9)!”.

console.log(markHigherBMI ? `Mark's BMI (${markBMI}) is higher than John's (${johnBMI})` : `John's BMI (${johnBMI}) is higher than Mark's (${markBMI})`);