// Lab 4.1. Hàm (10 phút)

// Viết hàm 'describeCountry' nhận ba tham số: 'country', 'population' và 'capitalCity'. Dựa vào input này, hàm trả về string với định dạng như sau: 'Finland has 6 million people and its capital city is Helsinki'.
// Gọi hàm này 3 lần với dữ liệu đầu vào cho 3 nước khác nhau. Lưu các giá trị trả về ở 3 biến khác nhau, và in chúng ra console.

function describeCountry(country, population, capitalCity) {
    return `${country} has ${population} million people and its capital city is ${capitalCity}`
}

let data1 = ["Vietnam", 80, "Hanoi"]
let data2 = ["Lao", 20, "Vientian"]
let data3 = ["Thailand", 50, "Bangkok"]

console.log(describeCountry(...data1))
console.log(describeCountry(...data2))
console.log(describeCountry(...data3))


/*Lab 4.2. Khai báo hàm với biểu thức hàm (20 phút)

Dân số thế giới là 7.9 tỷ người. Tạo khai báo hàm 'percentageOfWorld1' nhận một giá trị 'population' và trả về phần trăm dân số thế giới theo dân số đã cho. Ví dụ: Trung Quốc có 1.441 tỷ người, chiếm 18.2% dân số thế giới.
Để tính phần trăm, chia giá trị 'population' đã biết cho 7900 rồi nhân với 100.
Gọi 'percentageOfWorld1' cho 3 dân số của các quốc gia bất kỳ, lưu kết quả vào các biến và in chúng ra console.
Tạo biểu thức hàm thực hiện điều tương tự, gọi là 'percentageOfWorld2' và cũng gọi nó với 3 dân số theo quốc gia (có thể có cùng số dân).
*/

function percentageOfWorld1(population) {
    return Math.round(population / 7900 * 100) / 100
}

let percentVN = percentageOfWorld1(data1[1])
console.log(percentVN);

function percentageOfWorld2(population) {
    return Math.round(population / 7900 * 100) / 100
}

// Lab 4.3. Hàm mũi tên (5 phút)

// Thực hiện lại bài lab trước, nhưng lần này hãy tạo một hàm mũi tên là 'percentageOfWorld3'.

const percentageOfWorld3 = (population) => Math.round(population / 7900 * 100) / 100

/*Lab 4.4. Hàm gọi hàm (15 phút)

Tạo một hàm là 'describePopulation'. Sử dụng kiểu hàm mà bạn muốn nhất. Hàm này nhận hai đối số là 'country' và 'population', và trả về string như sau: 'China has 1441 million people, which is about 18.2% of the world'.
Để tính phần trăm 'describePopulation', hãy gọi 'percentageOfWorld1' mà bạn đã tạo trước đó.
Gọi 'describePopulation' với dữ liệu cho 3 nước bất kỳ.
*/

function describePopulation(country, population) {
    return `${country} has ${population} million people, which is about ${percentageOfWorld3(population)}% of the world`
}

describePopulation("Vietnam", 80)
describePopulation("Laos", 30)
describePopulation("China", 1700)

/*Lab 4.5. Giới thiệu về Array (15 phút)

Tạo một array chứa 4 giá trị dân số của 4 quốc gia bất kỳ. Bạn có thể sử dụng các giá trị đã dùng trước đó. Lưu array này vào một biến là 'populations'.
In ra console xem liệu array có 4 phần tử hay không (true hoặc false).
Tạo một array là 'percentages' có chứa phần trăm dân số thế giới của 4 giá trị dân số đó. Sử dụng hàm 'percentageOfWorld1' mà bạn đã tạo trước đó để tính toán 4 giá trị phần trăm.
*/

let populations = [10, 80, 90, 1000]

if (populations.length == 4) {
    console.log(true);
} else {
    console.log(false)
}

let percentages = [percentageOfWorld1(90), percentageOfWorld1(1000), percentageOfWorld1(2000), percentageOfWorld1(500)]

/*Lab 4.6. Các phép toán cơ bản với array (25 phút)

Tạo một array chứa tất cả các nước láng giềng của một nước bất kỳ. Chọn một nước có ít nhất 2 hoặc 3 nước láng giềng. Lưu array vào biến 'neighbours'.
Ở một số thời điểm, một đất nước mới là 'Utopia' được tạo ra trong vùng lân cận của quốc gia bạn chọn. Vậy hãy thêm nó vào cuối array 'neighbours'.
Không may, sau một thời gian, nước mới này biến mất. Vậy hãy xóa nó khỏi cuối array.
Nếu array 'neighbours' không chứa nước 'Germany', hãy in ra console rằng: 'Probably not a central European country :D'.
Thay đổi tên của một trong các nước láng giềng của bạn. Để thực hiện điều đó, hãy tìm chỉ mục của đất nước trong array 'neighbours', rồi sử dụng nó để thay đổi array ở vị trí chỉ mục đó. Chẳng hạn, nếu bạn tìm thấy 'Sweden' trong array, hãy thay nó bằng 'Republic of Sweden'.
*/

let neighbours = ['England', 'China', 'Finland', 'France']

neighbours.push('Utopia')

neighbours.pop()

if (!neighbours.includes('Germany')) {
    console.log('Probably not a central European country :D');
}

neighbours[1] = 'Vietnam'


// 4.7

const calcAverage = (a, b, c) => (a + b + c) / 3;

console.log(calcAverage(3, 4, 5));

let scoreDolphins = calcAverage(44, 23, 71)
let scoreKoalas = calcAverage(65, 54, 49)
console.log((scoreDolphins, scoreKoalas));

const checkWinner = function (avgDolphins, avgKoalas) {
    if (avgDolphins >= 2 * avgKoalas) {
        console.log(`Dolphins win (${avgDolphins} vs. ${avgKoalas})`);
    } else if (avgKoalas >= 2 * avgDolphins) {
        console.log(`Koalas win (${avgKoalas} vs. ${avgDolphins})`);
    } else {
        console.log('No team wins...');
    }
}

checkWinner(scoreDolphins, scoreKoalas)

checkWinner(576, 111)

scoreDolphins = calcAverage(85, 54, 41)
scoreKoalas = calcAverage(23, 34, 27)

console.log(scoreDolphins, scoreKoalas);
checkWinner(scoreDolphins, scoreKoalas)


// 4.7.2
const calcTip = function(bill) {
    return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
}

const bills = [125, 555, 44]

const tips = [calcTip(bills[0]), calcTip(bills[1]), calcTip(bills[2])]
const totals = [bills[0] + tips[0], bills[1] + tips[1], bills[2], tips[2]]

console.log(bills, tips, totals)

export { populations, percentageOfWorld1 }