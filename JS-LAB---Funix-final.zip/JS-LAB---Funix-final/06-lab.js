const data1 = [17, 21, 23]
const data2 = [12, 5, -5, 0, 4]

function printForecast(data) {
    let result = ""
    data.forEach((tem, idx) => result += `...${tem}ºC in ${idx}day`)
    console.log(result);
}