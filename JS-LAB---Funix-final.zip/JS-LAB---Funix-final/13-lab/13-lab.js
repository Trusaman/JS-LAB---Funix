// Lab 13.1: Tạo Object

// 1. Nhiệm vụ của bạn

// Sử dụng một hàm tạo để triển khai 'Car'. Một chiếc ô tô có thuộc tính 'make' và 'speed'. Thuộc tính 'speed' là tốc độ hiện tại của ô tô tính bằng km/h.
// Triển khai phương thức 'accelerate' tăng tốc độ của ô tô thêm 10 km/h và in tốc độ mới ra console.
// Triển khai phương thức 'brake' giảm bớt tốc độ của ô tô 5 km/h và in tốc độ mới ra console.
// Tạo 2 object 'Car' và thử nghiệm với 'accelerate' và 'brake' nhiều lần trên mỗi object.

function Car(make, speed) {
    this.make = make;
    this.speed = speed
}

Car.prototype.accelerate = function () {
    this.speed += 10
    console.log(this.speed);
}

Car.prototype.brake = function () {
    this.speed -= 5
    console.log(this.speed);
}

const bmw = new Car("BMW", 130)
bmw.accelerate()
bmw.brake()









// Lab 13.2: Sử dụng ES6 Class

// 1. Nhiệm vụ của bạn

// Tạo lại như class Car lab 13.1, nhưng lần này sử dụng ES6 class (gọi nó là 'CarCl').
// Thêm một getter là 'speedUS', trả về tốc độ hiện tại tính bằng mile/h (bạn cần quy điểm km/h thành mile/h bằng cách chia cho 1.6).
// Thêm một setter gọi là 'speedUS' để đặt giá trị tốc độ hiện tại tính bằng mile/h. (giá trị của tham số sẽ là ở mile/h, khi lưu vào object thì bạn sẽ lưu ở đơn vị km/h bằng cách nhân với 1.6).
// Tạo một đối tượng Car mới, thử nghiệm với phương thức 'accelerate' và 'brake', với getter và setter.

class CarCI {
    constructor(make, speed) {
        this.make = make;
        this.speed = speed
    }
    accelerate() {
        this.speed += 10
        console.log(this.speed);
    }
    brake() {
        this.speed -= 5
        console.log(this.speed);
    }
    get speedUS() {
        return this.speed / 1.6
    }
    set speedUS(newSpeed) {
        this.speed = newSpeed * 1.6
    }
}

let mazda = new CarCI("Mazda", 2000)
console.log(mazda.speedUS)
mazda.speedUS = 2000

/*Lab 13.3: Tính kế thừa

1. Nhiệm vụ của bạn

Sử dụng hàm tạo để triển khai Xe điện (được gọi là 'EV') dưới dạng child "class" của 'Car'. Bên cạnh nhãn hiệu và tốc độ hiện tại, 'EV' còn có mức sạc pin hiện tại tính theo % (thuộc tính 'charge')
Triển khai phương thức 'chargeBattery' có đối số 'chargeTo' và đặt mức sạc pin thành 'chargeTo' 
Triển khai phương thức 'accelerate' để tăng tốc độ của ô tô thêm 20 km/h và giảm 1% mức pin. Sau đó in ra thông báo như sau 'Tesla going at 140 km/h, with a charge of 22%'
Tạo object electric car và thử nghiệm với 'accelerate', 'brake' và 'chargeBattery' (sạc đến 90%). Lưu ý điều gì sẽ xảy ra khi bạn tăng tốc! Gợi ý: Xem lại định nghĩa của tính đa hình (polymorphism)
2. Dữ liệu kiểm tra

Dữ liệu car 1: 'Tesla' đi với tốc độ 120 km/h, với mức sạc pin là 23%
*/

function EV(make, speed, charge) {
    Car.call(this, make, speed);
    this.charge = charge
}

EV.prototype.chargeBattery = function(chargeTo) {
    this.charge = chargeTo
}

EV.prototype.accelerate = function() {
    this.speed += 20;
    this.charge -= 1;
    console.log(`${this.make} going at ${this.speed} km/h, with a charge of ${this.charge}%`)
}

/*Lab 13.4: Tính kế thừa sử dụng ES6

1. Nhiệm vụ của bạn

Tạo các Class ở  Lab 13.3, nhưng lần này hãy sử dụng ES6 class: tạo child class ‘EVCI’ của class 'CarCl'.
Đặt thuộc tính ‘charge’ ở chế độ riêng tư (private).
Triển khai khả năng liên kết các phương thức 'accelerate' và 'chargeBattery' của class này, đồng thời cập nhật phương thức 'brake' trong class 'CarCl'. Sau đó, thử nghiệm với chaining.
2. Dữ liệu kiểm tra

Dữ liệu car 1: 'Rivian' đi với tốc độ 120 km/h, với mức sạc pin là 23%
*/

class EVCI extends CarCI {
    #charge
    constructor(make, speed) {
        super(make, speed);
        this.#charge = 100
    }
    accelerate() {
        this.speed += 20;
        this.#charge -= 1;
        console.log(`${this.make} going at ${this.speed} km/h, with a charge of ${this.#charge}%`)
        return this
    }
    chargeBattery(chargeTo) {
        this.#charge = chargeTo
        return this
    }
    brake() {
        this.speed -= 10
        return this
    }
}


