console.log('9' - '5');

console.log('19' - '13' + '17');

console.log('19' - '13' + 17);

console.log('123' < 57);
console.log(5 + 6 + '4' + 9 - 4 - 2);

// Lab 3.2. Toán tử bằng: == với === (40 phút)

// Khai báo biến 'numNeighbours' dựa trên prompt input sau: prompt('How many neighbor countries does your country have?'). Bạn có thể tìm hiểu cách sử dụng hàm prompt để lấy dữ liệu từ người dùng ở link sau.
// Nếu chỉ có 1 neighbour, hãy in ra console 'Only 1 border!' (sử dụng ==).
// Sử dụng else-if block để ghi 'More than 1 border' trong trường hợp 'numNeighbours' lớn hơn 1.
// Sử dụng else block để ghi 'No borders' (block này sẽ được thực thi khi 'numNeighbours' là 0 hoặc bất kỳ giá trị nào khác).
// Kiểm tra code với các giá trị 'numNeighbours' khác nhau, gồm 1 và 0.
// Thay == thành ===, và kiểm tra lại code với các giá trị 'numNeighbours' tương tự. Điều gì sẽ xảy ra khi numNeighbours = 1? Tại sao lại như vậy?
// Cuối cùng, chuyển đổi 'numNeighbours' thành một số, và xem điều gì sẽ xảy ra khi bạn nhập vào 1.
// Hãy nêu lý do chúng ta nên sử dụng toán tử === và chuyển đổi kiểu trong trường hợp này.

// let numNeighbours = prompt('How many neighbor countries does your country have?')
// if (numNeighbours == 1) {
//     console.log("Only 1 border!");
// } else if (numNeighbours > 1) {
//     console.log("More than 1 border");
// } else {
//     console.log("No borders");
// }



// let numNeighbours = parseInt(prompt('How many neighbor countries does your country have?'))
// if (numNeighbours === 1) {
//     console.log("Only 1 border!");
// } else if (numNeighbours > 1) {
//     console.log("More than 1 border");
// } else {
//     console.log("No borders");
// }

// Lab 3.3. Toán tử logic (25 phút)

// Hãy vô hiệu hóa code trước đó để prompt không xuất hiện.
// Giả sử Sarah đang tìm một quốc gia mới để sinh sống. Cô ấy muốn ở một đất nước sử dụng ngôn ngữ Tiếng Anh, dân số ít hơn 50 triệu người và không phải đảo quốc.
// Bạn cần tạo các biến tương ứng với ngôn ngữ, dân số, có phải đảo quôcs không. Giá trị các biến này sẽ được nhập bằng hàm prompt.
// Hãy viết một câu lệnh if giúp Sarah tìm kiếm quốc gia phù hợp. Bạn cần viết điều kiện đánh giá  tất cả các tiêu chí của Sarah. Hãy dành thời gian thực hiện điều này.
// Nếu đất nước nhập vào phù hợp, in ra string như sau: 'You should live in Portugal :)'. Ngược lại, hãy in 'Portugal does not meet your criteria :('
// Có thể đất nước mà bạn nhập không đáp ứng toàn bộ tiêu chí. Hãy quay trở lại và thay đổi tạm thời một số biến để điều kiện trở nên đúng (trừ khi bạn sống ở Canada).

let country = prompt("The country?")
let language = prompt("The language: ")
let population = prompt("How many people are there? (The number must be in millions")
let isIsland = Boolean(prompt("Is it an island?"))

if (language.toLowerCase() == "english" && population > 50 && isIsland == false) {
    // value if true
    console.log(`You should live in ${country} :)`);
} else {
    console.log(`${country} does not meet your criteria :(`);
}

// Lab 3.4. Câu lệnh switch (5 phút)


// Sử dụng câu lệnh switch để ghi string sau cho 'language': 
switch (language.toLowerCase()) {
// Chinese or Mandarin: 'MOST number of native speakers!'
    case "chinese":
        console.log("MOST number of native speakers!");
        break  
    case "mandarin":
        console.log("MOST number of native speakers!");   
        break
// Spanish: '2nd place in number of native speakers'
    case "spanish":
        console.log("2nd place in number of native speakers");
        break
// English: '3rd place'
    case "english":
        console.log("3rd place");
        break
// Hindi: 'Number 4'
    case "hindi":
        console.log("Number 4");
        break
// Arabic: '5th most spoken language'
    case "arabic":
        console.log("5th most spoken language");
        break
// Tất cả các log đơn giản khác 'Great language too :D'
    default:
        console.log("Great language too :D");

}

// Lab 3.5. Toán tử điều kiện (ba ngôi) (10 phút)

// Nếu dân số của đất nước lớn hơn 33 triệu người, sử dụng toán tử ba ngôi để in string sau ra console: 'Portugal's population is above average'. Ngược lại, hãy in 'Portugal's population is below average'. Lưu ý giữa hai câu này chỉ có một từ thay đổi!

console.log(population > 33 ? `${country}'s population is above average` : `${country}'s population is below average`);